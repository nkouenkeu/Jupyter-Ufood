what is the weight of the five categories(wine,rare meat product,exotic fruits, prepared fish, sweet product)?
what is the impact of the different campaign of marketing?
what is the most valuable sell place( Web, store or catalogue)?
what is the link between the age, income according to the orders?

HYPOTHESES
The high order according to the age and income
The best marketing campaign customer_day
The best place selling place according to the income



```python
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
```


```python
ufood = pd.read_csv(r'C:\Users\alain abega\Downloads\Documents\U_food_marketing.csv')

pd.set_option('display.max.rows', 2260)
pd.set_option('display.max.columns', 50)
```


```python
#pd.options.display.float_format = '{:,.2f}'.format
```


```python
ufood.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Income</th>
      <th>Kidhome</th>
      <th>Teenhome</th>
      <th>Recency</th>
      <th>MntWines</th>
      <th>MntFruits</th>
      <th>MntMeatProducts</th>
      <th>MntFishProducts</th>
      <th>MntSweetProducts</th>
      <th>MntGoldProds</th>
      <th>NumDealsPurchases</th>
      <th>NumWebPurchases</th>
      <th>NumCatalogPurchases</th>
      <th>NumStorePurchases</th>
      <th>NumWebVisitsMonth</th>
      <th>AcceptedCmp3</th>
      <th>AcceptedCmp4</th>
      <th>AcceptedCmp5</th>
      <th>AcceptedCmp1</th>
      <th>AcceptedCmp2</th>
      <th>Complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>Response</th>
      <th>Age</th>
      <th>Customer_Days</th>
      <th>marital_Divorced</th>
      <th>marital_Married</th>
      <th>marital_Single</th>
      <th>marital_Together</th>
      <th>marital_Widow</th>
      <th>education_2n Cycle</th>
      <th>education_Basic</th>
      <th>education_Graduation</th>
      <th>education_Master</th>
      <th>education_PhD</th>
      <th>MntTotal</th>
      <th>MntRegularProds</th>
      <th>AcceptedCmpOverall</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>58138.0</td>
      <td>0</td>
      <td>0</td>
      <td>58</td>
      <td>635</td>
      <td>88</td>
      <td>546</td>
      <td>172</td>
      <td>88</td>
      <td>88</td>
      <td>3</td>
      <td>8</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>1</td>
      <td>63</td>
      <td>2822</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1529</td>
      <td>1441</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>46344.0</td>
      <td>1</td>
      <td>1</td>
      <td>38</td>
      <td>11</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>66</td>
      <td>2272</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>21</td>
      <td>15</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>71613.0</td>
      <td>0</td>
      <td>0</td>
      <td>26</td>
      <td>426</td>
      <td>49</td>
      <td>127</td>
      <td>111</td>
      <td>21</td>
      <td>42</td>
      <td>1</td>
      <td>8</td>
      <td>2</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>55</td>
      <td>2471</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>734</td>
      <td>692</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26646.0</td>
      <td>1</td>
      <td>0</td>
      <td>26</td>
      <td>11</td>
      <td>4</td>
      <td>20</td>
      <td>10</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>36</td>
      <td>2298</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>43</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>58293.0</td>
      <td>1</td>
      <td>0</td>
      <td>94</td>
      <td>173</td>
      <td>43</td>
      <td>118</td>
      <td>46</td>
      <td>27</td>
      <td>15</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>39</td>
      <td>2320</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>407</td>
      <td>392</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
ufood.drop_duplicates(keep = False, inplace = True)
```


```python
ufood['Total_children']=ufood[['Kidhome', 'Teenhome']].sum(axis = 1) 
```


```python
ufood[ufood['Marital_Status'] != 0].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Income</th>
      <th>Kidhome</th>
      <th>Teenhome</th>
      <th>Recency</th>
      <th>MntWines</th>
      <th>MntFruits</th>
      <th>MntMeatProducts</th>
      <th>MntFishProducts</th>
      <th>MntSweetProducts</th>
      <th>MntGoldProds</th>
      <th>NumDealsPurchases</th>
      <th>NumWebPurchases</th>
      <th>NumCatalogPurchases</th>
      <th>NumStorePurchases</th>
      <th>NumWebVisitsMonth</th>
      <th>AcceptedCmp3</th>
      <th>AcceptedCmp4</th>
      <th>AcceptedCmp5</th>
      <th>AcceptedCmp1</th>
      <th>AcceptedCmp2</th>
      <th>Complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>Response</th>
      <th>Age</th>
      <th>Customer_Days</th>
      <th>marital_Divorced</th>
      <th>marital_Married</th>
      <th>marital_Single</th>
      <th>marital_Together</th>
      <th>marital_Widow</th>
      <th>education_2n Cycle</th>
      <th>education_Basic</th>
      <th>education_Graduation</th>
      <th>education_Master</th>
      <th>education_PhD</th>
      <th>MntTotal</th>
      <th>MntRegularProds</th>
      <th>AcceptedCmpOverall</th>
      <th>Marital_Status</th>
      <th>Marital_Status_str</th>
      <th>Education_Status</th>
      <th>Education_Status_str</th>
      <th>Accepted_Campaigns</th>
      <th>Age_Group</th>
      <th>Total_children</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>58138.0</td>
      <td>0</td>
      <td>0</td>
      <td>58</td>
      <td>635</td>
      <td>88</td>
      <td>546</td>
      <td>172</td>
      <td>88</td>
      <td>88</td>
      <td>3</td>
      <td>8</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>1</td>
      <td>63</td>
      <td>2822</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1529</td>
      <td>1441</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>1</td>
      <td>61 - 70</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>46344.0</td>
      <td>1</td>
      <td>1</td>
      <td>38</td>
      <td>11</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>66</td>
      <td>2272</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>21</td>
      <td>15</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>61 - 70</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>71613.0</td>
      <td>0</td>
      <td>0</td>
      <td>26</td>
      <td>426</td>
      <td>49</td>
      <td>127</td>
      <td>111</td>
      <td>21</td>
      <td>42</td>
      <td>1</td>
      <td>8</td>
      <td>2</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>55</td>
      <td>2471</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>734</td>
      <td>692</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>51 - 60</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26646.0</td>
      <td>1</td>
      <td>0</td>
      <td>26</td>
      <td>11</td>
      <td>4</td>
      <td>20</td>
      <td>10</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>36</td>
      <td>2298</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>43</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>31 - 40</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>58293.0</td>
      <td>1</td>
      <td>0</td>
      <td>94</td>
      <td>173</td>
      <td>43</td>
      <td>118</td>
      <td>46</td>
      <td>27</td>
      <td>15</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>39</td>
      <td>2320</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>407</td>
      <td>392</td>
      <td>0</td>
      <td>4</td>
      <td>Married</td>
      <td>5</td>
      <td>education_PhD</td>
      <td>0</td>
      <td>31 - 40</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
ufood['marital_Divorced'] = ufood['marital_Divorced'].replace({1:5, 0:0})
ufood['marital_Married'] = ufood['marital_Married'].replace({1:4, 0:0})
ufood['marital_Single'] = ufood['marital_Single'].replace({1:3, 0:0})
ufood['marital_Together'] = ufood['marital_Together'].replace({1:2, 0:0})
ufood['marital_Widow'] = ufood['marital_Widow'].replace({1:1, 0:0})
```


```python
# Sum of the Status columns through a list 
ufood['Marital_Status'] = ufood[['marital_Divorced','marital_Married','marital_Single', 'marital_Together','marital_Widow']].sum(axis=1)
```


```python
# transform th int to str, because we want to groupby and do visualization 
ufood['Marital_Status_str'] = ufood['Marital_Status'].map({5:'Divorced', 4:'Married', 3:'Single', 2:'Together', 1:'Widow'})
```


```python
ufood.columns
```




    Index(['Income', 'Kidhome', 'Teenhome', 'Recency', 'MntWines', 'MntFruits',
           'MntMeatProducts', 'MntFishProducts', 'MntSweetProducts',
           'MntGoldProds', 'NumDealsPurchases', 'NumWebPurchases',
           'NumCatalogPurchases', 'NumStorePurchases', 'NumWebVisitsMonth',
           'AcceptedCmp3', 'AcceptedCmp4', 'AcceptedCmp5', 'AcceptedCmp1',
           'AcceptedCmp2', 'Complain', 'Z_CostContact', 'Z_Revenue', 'Response',
           'Age', 'Customer_Days', 'marital_Divorced', 'marital_Married',
           'marital_Single', 'marital_Together', 'marital_Widow',
           'education_2n Cycle', 'education_Basic', 'education_Graduation',
           'education_Master', 'education_PhD', 'MntTotal', 'MntRegularProds',
           'AcceptedCmpOverall', 'Marital_Status', 'Marital_Status_str'],
          dtype='object')




```python
# let#s use the same process for education level
ufood['education_2n Cycle'] = ufood['education_2n Cycle'].replace({1:1, 0:0})
ufood['education_Basic'] = ufood['education_Basic'].replace({1:2, 0:0})
ufood['education_Graduation'] = ufood['education_Graduation'].replace({1:3, 0:0})
ufood['education_Master'] = ufood['education_Master'].replace({1:4, 0:0})
ufood['education_PhD'] = ufood['education_PhD'].replace({1:5, 0:0})
```


```python
ufood['Education_Status'] = ufood[['education_2n Cycle','education_Basic','education_Graduation', 'education_Master','education_PhD']].sum(axis=1)
```


```python
ufood[ufood['Education_Status'] != 0].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Income</th>
      <th>Kidhome</th>
      <th>Teenhome</th>
      <th>Recency</th>
      <th>MntWines</th>
      <th>MntFruits</th>
      <th>MntMeatProducts</th>
      <th>MntFishProducts</th>
      <th>MntSweetProducts</th>
      <th>MntGoldProds</th>
      <th>NumDealsPurchases</th>
      <th>NumWebPurchases</th>
      <th>NumCatalogPurchases</th>
      <th>NumStorePurchases</th>
      <th>NumWebVisitsMonth</th>
      <th>AcceptedCmp3</th>
      <th>AcceptedCmp4</th>
      <th>AcceptedCmp5</th>
      <th>AcceptedCmp1</th>
      <th>AcceptedCmp2</th>
      <th>Complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>Response</th>
      <th>Age</th>
      <th>Customer_Days</th>
      <th>marital_Divorced</th>
      <th>marital_Married</th>
      <th>marital_Single</th>
      <th>marital_Together</th>
      <th>marital_Widow</th>
      <th>education_2n Cycle</th>
      <th>education_Basic</th>
      <th>education_Graduation</th>
      <th>education_Master</th>
      <th>education_PhD</th>
      <th>MntTotal</th>
      <th>MntRegularProds</th>
      <th>AcceptedCmpOverall</th>
      <th>Marital_Status</th>
      <th>Marital_Status_str</th>
      <th>Education_Status</th>
      <th>Education_Status_str</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>58138.0</td>
      <td>0</td>
      <td>0</td>
      <td>58</td>
      <td>635</td>
      <td>88</td>
      <td>546</td>
      <td>172</td>
      <td>88</td>
      <td>88</td>
      <td>3</td>
      <td>8</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>1</td>
      <td>63</td>
      <td>2822</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1529</td>
      <td>1441</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
    </tr>
    <tr>
      <th>1</th>
      <td>46344.0</td>
      <td>1</td>
      <td>1</td>
      <td>38</td>
      <td>11</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>66</td>
      <td>2272</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>21</td>
      <td>15</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
    </tr>
    <tr>
      <th>2</th>
      <td>71613.0</td>
      <td>0</td>
      <td>0</td>
      <td>26</td>
      <td>426</td>
      <td>49</td>
      <td>127</td>
      <td>111</td>
      <td>21</td>
      <td>42</td>
      <td>1</td>
      <td>8</td>
      <td>2</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>55</td>
      <td>2471</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>734</td>
      <td>692</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26646.0</td>
      <td>1</td>
      <td>0</td>
      <td>26</td>
      <td>11</td>
      <td>4</td>
      <td>20</td>
      <td>10</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>36</td>
      <td>2298</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>43</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
    </tr>
    <tr>
      <th>4</th>
      <td>58293.0</td>
      <td>1</td>
      <td>0</td>
      <td>94</td>
      <td>173</td>
      <td>43</td>
      <td>118</td>
      <td>46</td>
      <td>27</td>
      <td>15</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>39</td>
      <td>2320</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>407</td>
      <td>392</td>
      <td>0</td>
      <td>4</td>
      <td>Married</td>
      <td>1</td>
      <td>education_PhD</td>
    </tr>
  </tbody>
</table>
</div>




```python
#ufood['Education_Status_str'] = ufood['Education_Status'].map({1:'education_2n Cycle', 2:'education_Basic', 3:'education_Graduation', 4:'education_Master', 5:'education_PhD'})
```


```python
# Just need to add all the campaigns columns in one column.
ufood['Accepted_Campaigns'] =  ufood[['AcceptedCmp3','AcceptedCmp4','AcceptedCmp5', 'AcceptedCmp1','AcceptedCmp2','Response']].sum(axis=1)
```


```python
ufood['Accepted_Campaigns'] = (ufood['Accepted_Campaigns'] != 0).astype(int)
```


```python
# let's start with the correlation,to improve the performance of marketing activities,a special focus on marketing campaigns
ufood.corr(method = 'pearson',min_periods = 1,numeric_only = True)['Accepted_Campaigns'].sort_values(ascending=False)
```




    Accepted_Campaigns      1.000000
    AcceptedCmpOverall      0.716343
    Response                0.686667
    AcceptedCmp4            0.461506
    AcceptedCmp3            0.459984
    AcceptedCmp5            0.456930
    AcceptedCmp1            0.427141
    MntWines                0.420524
    MntTotal                0.398858
    MntRegularProds         0.396973
    NumCatalogPurchases     0.326084
    MntMeatProducts         0.306944
    Income                  0.299464
    NumWebPurchases         0.218926
    AcceptedCmp2            0.191209
    MntGoldProds            0.190478
    MntSweetProducts        0.162932
    MntFishProducts         0.158646
    NumStorePurchases       0.147642
    MntFruits               0.139401
    Customer_Days           0.084786
    education_PhD           0.065778
    marital_Single          0.047763
    Age                     0.031907
    marital_Widow           0.028886
    Education_Status        0.028865
    marital_Divorced        0.019954
    education_Master       -0.001939
    Marital_Status         -0.003553
    education_Graduation   -0.018054
    Complain               -0.026585
    marital_Together       -0.029273
    NumDealsPurchases      -0.031437
    education_2n Cycle     -0.032855
    marital_Married        -0.037430
    education_Basic        -0.051265
    NumWebVisitsMonth      -0.071444
    Recency                -0.102181
    Teenhome               -0.128871
    Kidhome                -0.166784
    Z_CostContact                NaN
    Z_Revenue                    NaN
    Name: Accepted_Campaigns, dtype: float64




```python
sns.heatmap(ufood.corr(method = 'pearson',min_periods = 0,numeric_only = True))
```




    <Axes: >




    
![png](output_20_1.png)
    



```python
all_correlations = ufood.corr(method = 'pearson', min_periods = 0, numeric_only = True)
all_correlations = all_correlations[(all_correlations > 0.3) & (all_correlations < 1)]

sns.heatmap(all_correlations)
```




    <Axes: >




    
![png](output_21_1.png)
    



```python
#let's look for the data 
all_correlations['Accepted_Campaigns']
```




    Income                       NaN
    Kidhome                      NaN
    Teenhome                     NaN
    Recency                      NaN
    MntWines                0.420524
    MntFruits                    NaN
    MntMeatProducts         0.306944
    MntFishProducts              NaN
    MntSweetProducts             NaN
    MntGoldProds                 NaN
    NumDealsPurchases            NaN
    NumWebPurchases              NaN
    NumCatalogPurchases     0.326084
    NumStorePurchases            NaN
    NumWebVisitsMonth            NaN
    AcceptedCmp3            0.459984
    AcceptedCmp4            0.461506
    AcceptedCmp5            0.456930
    AcceptedCmp1            0.427141
    AcceptedCmp2                 NaN
    Complain                     NaN
    Z_CostContact                NaN
    Z_Revenue                    NaN
    Response                0.686667
    Age                          NaN
    Customer_Days                NaN
    marital_Divorced             NaN
    marital_Married              NaN
    marital_Single               NaN
    marital_Together             NaN
    marital_Widow                NaN
    education_2n Cycle           NaN
    education_Basic              NaN
    education_Graduation         NaN
    education_Master             NaN
    education_PhD                NaN
    MntTotal                0.398858
    MntRegularProds         0.396973
    AcceptedCmpOverall      0.716343
    Marital_Status               NaN
    Education_Status             NaN
    Accepted_Campaigns           NaN
    Name: Accepted_Campaigns, dtype: float64




```python
# The first is to analyze the age 
#ufood['Age'].sort_values()
ufood['Age'].nunique()
```




    56




```python
age_groups = [(23,30),(31,40),(41,50), (51,60), (61,70),(71,85)]

def assign_age_group(Age):
    for age_range in age_groups:
        if age_range[0]<= Age <= age_range[1]:
            return f"{age_range[0]} - {age_range[1]}"
    return("unknown")
    
ufood['Age_Group'] = ufood['Age'].apply(assign_age_group)
```


```python
ufood[['Age','Age_Group']].head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Age</th>
      <th>Age_Group</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>63</td>
      <td>61 - 70</td>
    </tr>
    <tr>
      <th>1</th>
      <td>66</td>
      <td>61 - 70</td>
    </tr>
    <tr>
      <th>2</th>
      <td>55</td>
      <td>51 - 60</td>
    </tr>
    <tr>
      <th>3</th>
      <td>36</td>
      <td>31 - 40</td>
    </tr>
    <tr>
      <th>4</th>
      <td>39</td>
      <td>31 - 40</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Try to put the age in the range values.
age_order = ['23 - 30','31 - 40','41 - 50', '51 - 60', '61 - 70','71 - 85']

sns.pointplot(data = ufood, x = 'Age_Group', y = 'Accepted_Campaigns', order = age_order)
plt.title('percentage per age')
```




    <Axes: xlabel='Age_Group', ylabel='Accepted_Campaigns'>




    
![png](output_26_1.png)
    



```python
# Find the correct number of cunsummer par age range
counts =ufood['Age_Group'].value_counts()
```


```python
percentage = counts / ufood.shape[0]
```


```python
# reset_index 
percent_ufood = percentage.reset_index()
```


```python
# columns names
percent_ufood.columns = ['age_group','percentage']
```


```python
percent_ufood = percent_ufood.sort_values('age_group')
```


```python
percent_ufood
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>age_group</th>
      <th>percentage</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>5</th>
      <td>23 - 30</td>
      <td>0.027664</td>
    </tr>
    <tr>
      <th>3</th>
      <td>31 - 40</td>
      <td>0.161905</td>
    </tr>
    <tr>
      <th>0</th>
      <td>41 - 50</td>
      <td>0.329705</td>
    </tr>
    <tr>
      <th>1</th>
      <td>51 - 60</td>
      <td>0.227664</td>
    </tr>
    <tr>
      <th>2</th>
      <td>61 - 70</td>
      <td>0.205442</td>
    </tr>
    <tr>
      <th>4</th>
      <td>71 - 85</td>
      <td>0.047619</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(data = percent_ufood, x = 'age_group', y = 'percentage')
plt.title('percentage per age')
plt.show()
```


    
![png](output_33_0.png)
    



```python
# The accepted campaigns is between 31 and 70 age 
```


```python
# Now is to know how much they spend per age 
group_ufood = ufood.groupby('Age_Group')[['MntTotal']].sum().reset_index()
sns.barplot(data = group_ufood, x = 'Age_Group', y = 'MntTotal')
plt.title('spending per age')
plt.show()
```


    
![png](output_35_0.png)
    



```python
# There is two ways of proposition, the group between 23-30 and 71-85, spend less money than the other group by they are very open to say yes to campaing.
```


```python
# The percentage just increased a bit with the accepted_campaigns.
acc_campaign = ufood[ufood['Accepted_Campaigns'] != 0]

group_ufood = acc_campaign.groupby('Age_Group')[['MntTotal']].sum().reset_index()
sns.barplot(data =group_ufood , x = 'Age_Group', y = 'MntTotal')
plt.title('spending per age')
plt.show()
```


    
![png](output_37_0.png)
    



```python
# The other thing,we can also see it's the place they purchase.
ufood.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Income</th>
      <th>Kidhome</th>
      <th>Teenhome</th>
      <th>Recency</th>
      <th>MntWines</th>
      <th>MntFruits</th>
      <th>MntMeatProducts</th>
      <th>MntFishProducts</th>
      <th>MntSweetProducts</th>
      <th>MntGoldProds</th>
      <th>NumDealsPurchases</th>
      <th>NumWebPurchases</th>
      <th>NumCatalogPurchases</th>
      <th>NumStorePurchases</th>
      <th>NumWebVisitsMonth</th>
      <th>AcceptedCmp3</th>
      <th>AcceptedCmp4</th>
      <th>AcceptedCmp5</th>
      <th>AcceptedCmp1</th>
      <th>AcceptedCmp2</th>
      <th>Complain</th>
      <th>Z_CostContact</th>
      <th>Z_Revenue</th>
      <th>Response</th>
      <th>Age</th>
      <th>Customer_Days</th>
      <th>marital_Divorced</th>
      <th>marital_Married</th>
      <th>marital_Single</th>
      <th>marital_Together</th>
      <th>marital_Widow</th>
      <th>education_2n Cycle</th>
      <th>education_Basic</th>
      <th>education_Graduation</th>
      <th>education_Master</th>
      <th>education_PhD</th>
      <th>MntTotal</th>
      <th>MntRegularProds</th>
      <th>AcceptedCmpOverall</th>
      <th>Marital_Status</th>
      <th>Marital_Status_str</th>
      <th>Education_Status</th>
      <th>Education_Status_str</th>
      <th>Accepted_Campaigns</th>
      <th>Age_Group</th>
      <th>Total_children</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>58138.0</td>
      <td>0</td>
      <td>0</td>
      <td>58</td>
      <td>635</td>
      <td>88</td>
      <td>546</td>
      <td>172</td>
      <td>88</td>
      <td>88</td>
      <td>3</td>
      <td>8</td>
      <td>10</td>
      <td>4</td>
      <td>7</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>1</td>
      <td>63</td>
      <td>2822</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>1529</td>
      <td>1441</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>1</td>
      <td>61 - 70</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>46344.0</td>
      <td>1</td>
      <td>1</td>
      <td>38</td>
      <td>11</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>6</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>2</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>66</td>
      <td>2272</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>21</td>
      <td>15</td>
      <td>0</td>
      <td>3</td>
      <td>Single</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>61 - 70</td>
      <td>2</td>
    </tr>
    <tr>
      <th>2</th>
      <td>71613.0</td>
      <td>0</td>
      <td>0</td>
      <td>26</td>
      <td>426</td>
      <td>49</td>
      <td>127</td>
      <td>111</td>
      <td>21</td>
      <td>42</td>
      <td>1</td>
      <td>8</td>
      <td>2</td>
      <td>10</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>55</td>
      <td>2471</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>734</td>
      <td>692</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>51 - 60</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>26646.0</td>
      <td>1</td>
      <td>0</td>
      <td>26</td>
      <td>11</td>
      <td>4</td>
      <td>20</td>
      <td>10</td>
      <td>3</td>
      <td>5</td>
      <td>2</td>
      <td>2</td>
      <td>0</td>
      <td>4</td>
      <td>6</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>36</td>
      <td>2298</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>0</td>
      <td>0</td>
      <td>48</td>
      <td>43</td>
      <td>0</td>
      <td>2</td>
      <td>Together</td>
      <td>3</td>
      <td>education_Graduation</td>
      <td>0</td>
      <td>31 - 40</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>58293.0</td>
      <td>1</td>
      <td>0</td>
      <td>94</td>
      <td>173</td>
      <td>43</td>
      <td>118</td>
      <td>46</td>
      <td>27</td>
      <td>15</td>
      <td>5</td>
      <td>5</td>
      <td>3</td>
      <td>6</td>
      <td>5</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>3</td>
      <td>11</td>
      <td>0</td>
      <td>39</td>
      <td>2320</td>
      <td>0</td>
      <td>4</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>5</td>
      <td>407</td>
      <td>392</td>
      <td>0</td>
      <td>4</td>
      <td>Married</td>
      <td>5</td>
      <td>education_PhD</td>
      <td>0</td>
      <td>31 - 40</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
sum_ufood = pd.DataFrame(ufood[['NumWebPurchases','NumCatalogPurchases','NumStorePurchases']].sum(), columns =['Sum'])
```


```python
sum_ufood = sum_ufood.reset_index()
```


```python
sum_ufood.rename(columns={'index':'Purchases'}, inplace=True)
```


```python
sum_ufood.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Purchases</th>
      <th>Sum</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NumWebPurchases</td>
      <td>9042</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NumCatalogPurchases</td>
      <td>5833</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NumStorePurchases</td>
      <td>12841</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(data =sum_ufood,  x = 'Purchases', y = 'Sum' )
```




    <Axes: xlabel='Purchases', ylabel='Sum'>




    
![png](output_43_1.png)
    



```python
# Now we want to filter with accepted campaings
acc_campaign = ufood[ufood['Accepted_Campaigns'] != 0]

sum_ufood = pd.DataFrame(ufood[['NumWebPurchases','NumCatalogPurchases','NumStorePurchases']].sum(), columns =['Sum'])
sum_ufood = sum_ufood.reset_index()
sum_ufood.rename(columns={'index':'Purchases'}, inplace=True)
sns.barplot(data =sum_ufood,  x = 'Purchases', y = 'Sum')
plt.show()
```


    
![png](output_44_0.png)
    



```python
x = sns.jointplot(data = ufood, x = 'MntTotal', y = 'NumWebPurchases', kind = 'kde')
x.plot_joint(sns.regplot, color = 'r')
```




    <seaborn.axisgrid.JointGrid at 0x220a7eda910>




    
![png](output_45_1.png)
    



```python
x = sns.jointplot(data = ufood, x = 'MntTotal', y = 'NumCatalogPurchases', kind = 'kde')
x.plot_joint(sns.regplot, color = 'r')
```


```python
x = sns.jointplot(data = ufood, x = 'MntTotal', y = 'NumStorePurchases', kind = 'kde')
x.plot_joint(sns.regplot, color = 'r')
```


```python
#  Boost up the higher percentage or face on stores/web because they have more traffic
```


```python
# Child home 
sns.regplot(data = ufood, x = 'Total_children', y = 'Accepted_Campaigns')
```




    <Axes: xlabel='Total_children', ylabel='Accepted_Campaigns'>




    
![png](output_49_1.png)
    



```python
# no kids ready to accept campaign and spend more money, more kids no campaign accepeted(a bit difficult)
```


```python
# Education level
sns.regplot(data = ufood, x = 'Education_Status', y = 'MntTotal')
```




    <Axes: xlabel='Education_Status', ylabel='MntTotal'>




    
![png](output_51_1.png)
    



```python
# More educated people tend to accpet campaign, 
```


```python
#Status
sns.countplot(data =ufood,  x = 'Marital_Status_str')
plt.show()
```


    
![png](output_53_0.png)
    



```python
sns.regplot(data = ufood, x = 'Marital_Status', y = 'MntTotal')
```




    <Axes: xlabel='Marital_Status', ylabel='MntTotal'>




    
![png](output_54_1.png)
    



```python
rel_ufood = ufood.groupby('Marital_Status_str')['MntTotal'].sum().reset_index()
```


```python
sns.barplot(data= rel_ufood, x = 'Marital_Status_str', y = 'MntTotal')
```




    <Axes: xlabel='Marital_Status_str', ylabel='MntTotal'>




    
![png](output_56_1.png)
    



```python
total = ufood['Marital_Status_str'].value_counts()
accepted = ufood[ufood['Accepted_Campaigns'] == 1]['Marital_Status_str'].value_counts()
```


```python
perc_marital = accepted / total*100
perc_ufood = perc_marital.reset_index()
perc_ufood.columns = ['Marital_Status','Percentage']
sns.barplot(data= perc_ufood, x = 'Marital_Status', y = 'Percentage')
plt.show()
```


    
![png](output_58_0.png)
    



```python
# Married people spend more than the others
```


```python

```


```python

```
